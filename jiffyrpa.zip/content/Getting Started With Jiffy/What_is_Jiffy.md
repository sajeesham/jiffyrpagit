+++
title = "1. What is Jiffy?"
draft = false
date = "2016-11-07T14:03:40+05:30"
+++

Jiffy is a Robotic Automation tool which provides everything you need to implement a continuous automation framework, Reporting Automation, Cognitive Robots & analytics. Automate any task manually performed on a computer, rule based or non rule based. 

With simple drag and drop, automate any manual activity carried out across desktop applications, web applications or mainframes. The process is further simplified with nodes that can ease interactions wtih excel, email, REST, web services etc.

JIFFY can not only carryout an exact automation like any other RPA software, it can securely log into the application and execute actions on the application in the same way that an user would, you can also integrate directly with backend services exposed by applications where possible. This reduces the number of automation steps, is less error prone and is much easier to maintain.

